
# level (2) political_website/admin.py

from django.contrib import admin
from .models import ContactMessage

admin.site.register(ContactMessage)

