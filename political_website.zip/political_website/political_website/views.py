
# political_website - views

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import ContactMessage

def home(request):
    return render(request, 'home.html')

def about(request):
    return render(request, 'about.html')

def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')
        ContactMessage.objects.create(name=name, email=email, message=message)
        return redirect('home')
    return render(request, 'contact.html')

@login_required
def dashboard(request):
    return render(request, 'dashboard.html')




