
# political_wensite/apps.py

from django.apps import AppConfig

class MyAppConfig(AppConfig):
    name = 'political_website'

