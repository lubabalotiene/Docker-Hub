
# political_website/tests.py

from django.test import TestCase
from django.urls import reverse
from django.contrib.auth.models import User
from .models import ContactMessage

class ContactMessageModelTests(TestCase):
    def test_contact_message_creation(self):
        user = User.objects.create(username='testuser')
        contact_message = ContactMessage.objects.create(
            name='Test Name',
            email='test@example.com',
            message='Test message',
            user=user
        )
        self.assertEqual(contact_message.name, 'Test Name')
        self.assertEqual(contact_message.email, 'test@example.com')
        self.assertEqual(contact_message.message, 'Test message')
        self.assertEqual(contact_message.user, user)

class ViewsTests(TestCase):
    def test_home_view(self):
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Welcome to the Political Candidate Website')

    def test_about_view(self):
        response = self.client.get(reverse('about'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'About Our Candidate')

    def test_contact_view(self):
        response = self.client.get(reverse('contact'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Contact Us')

    def test_dashboard_view_authenticated(self):
        user = User.objects.create(username='testuser')
        self.client.force_login(user)
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'User Dashboard')

    def test_dashboard_view_unauthenticated(self):
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 302)  # Redirect to login page
